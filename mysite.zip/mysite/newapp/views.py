#-*- coding: UTF-8 -*-
from django.shortcuts import render
from django.shortcuts import HttpResponse
from newapp import models
from newapp.models import Student
import json
from newapp.models import University,GraduateUniver,University_Au,University_Ca,University_En
from newapp.forms import UserInfoForm
from .models import UserInfoFormModel
import sys,importlib
defaultencoding = 'utf-8'

# Create your views here.
countries_list = [
    {"name": "美国", "id": 1},
    {"name": "英国", "id": 2},
    {"name": "加拿大", "id": 3},
    {"name": "澳大利亚", "id": 4},
]

# ajax返回所选国家的大学列表
def getUniversityList(request):
    if request.method=="POST":
        country=request.POST.get("targetCountry").encode("utf-8");
        # 专业
        intention_major = request.POST.get("targetMajor")
        if country == '美国':#美国
            universities = University.objects.raw('SELECT *from newapp_university where major=%s GROUP BY name ORDER BY CONVERT(name USING gbk)',[intention_major])
        elif country == '英国':#英国
            universities = University_En.objects.raw('SELECT *from newapp_university_en where major=%s GROUP BY name ORDER BY CONVERT(name USING gbk)',[intention_major]);
        elif country == '澳大利亚': #澳大利亚
            universities = University_Au.objects.raw('SELECT *from newapp_university_au where major=%s  GROUP BY name ORDER BY CONVERT(name USING gbk)',[intention_major]);
       # elif country == "加拿大":
        #    universities = University.objects.raw('SELECT *from newapp_university_ca GROUP BY name ORDER BY CONVERT(name USING gbk)');
        universityName=[]
        universityLevel=[]
        universitycategoryLevel = []
        for u in universities:
            universityName.append(u.name)
            universityLevel.append(u.level)
            universitycategoryLevel.append(u.category_level)
        data={"universityName":universityName,"universitycategoryLevel":universitycategoryLevel}
        return HttpResponse(json.dumps(data),content_type='application/json');

def assessmentForm(request):
    if request.method == "POST":
        form = UserInfoForm(request.POST)
        if form.is_valid():
            studentFName = form.cleaned_data['first_name']
            studentLName = form.cleaned_data['last_name']
            if studentFName is None:
                studentFName= ''
            if studentLName is None:
                studentLName =''
            cell_phone_number=form.cleaned_data['cell_phone_number']
            # 获取国家的名字
            intention_countryName = form.cleaned_data['intention_country'].encode("utf-8")  # 国家名字 如果不使用encode的话就是Unicode编码，但是使用encode之后还不是中文。。。
            for coun in countries_list:
                if coun["name"] == intention_countryName:  # coun["name"]不是unicode编码，因此如果intention_countryName不使用encode的话是unicode编码，两者无法比较
                    intention_countryId = coun["id"]  # intention_countryId 国家Id

            # 想去的学校
            intention_school = form.cleaned_data['intention_school']# 学校的名称

            # 专业
            intention_major = form.cleaned_data['intention_major']

            # 本科院校gu_level
            gu_name=form.cleaned_data['graduate_school']
            gu_level = GraduateUniver.objects.raw('SELECT *from newapp_graduateuniver where name=%s',[gu_name])[0].gu_level

            # GPA
            GPA = float(form.cleaned_data['score_GPA'])
            rank_in_major=form.cleaned_data['ranking_in_major']

            # 雅思/托福
            IELTS_TOEFL = float(form.cleaned_data['score_IELTS_TOEFL'])  # 总分
            IT_Listening = float(form.cleaned_data['score_IT_Listening'])  # 听
            IT_Speaking = float(form.cleaned_data['score_IT_Speaking'])  # 听
            IT_Reading = float(form.cleaned_data['score_IT_Reading'])  # 读
            IT_Writing = float(form.cleaned_data['score_IT_Writing'])  # 写

            # GRE
            GRE_Total = form.cleaned_data['score_GRE']
            score_GRE_Verbal=form.cleaned_data['score_GRE_Verbal']
            score_GRE_Quan = form.cleaned_data['score_GRE_Quan']
            score_GRE_Anal = form.cleaned_data['score_GRE_Anal']
            if score_GRE_Verbal is None:
                score_GRE_Verbal=0
            if score_GRE_Quan is None:
                score_GRE_Quan=0
            if score_GRE_Anal is None:
                score_GRE_Anal=0

            # 获取加分项
            In_Papers = form.cleaned_data['in_papers']# paper篇数
            Na_Papers = form.cleaned_data['na_papers']

            In_Patents = form.cleaned_data['in_patent'] # 专利篇数
            Na_Patents = form.cleaned_data['na_patent']

            Research = form.cleaned_data['research']
            Placement = form.cleaned_data['placement']
            Social_Practice = form.cleaned_data['social_practice']
            Specilty = form.cleaned_data['specilty']

            Recommendation = form.cleaned_data['recommendation']

            # 根据获取的数据计算得分
            sum = 0
            GPA_good = False
            # 转换GPA的值
            if GPA >= 3.9:
                GPA_level = 1
                GPA_Trans = 100
            elif GPA >= 3.8:
                GPA_level = 1
                GPA_good = True
                GPA_Trans = 95
            elif GPA >= 3.7:
                GPA_level = 2
                GPA_good = True
                GPA_Trans = 90
            elif GPA >= 3.6:
                GPA_level = 2
                GPA_Trans = 85
            elif GPA >= 3.5:
                GPA_level = 2
                GPA_Trans = 80
            elif GPA >= 3.4:
                GPA_level = 3
                GPA_Trans = 75
            elif GPA >= 3.3:
                GPA_level = 3
                GPA_Trans = 70
            elif GPA >= 3.2:
                GPA_level = 3
                GPA_Trans = 65
            elif GPA >= 3.1:
                GPA_level = 3
                GPA_Trans = 60
            elif GPA >= 3.0:
                GPA_level = 4
                GPA_Trans = 55
            else:
                GPA_level = 5
                GPA_Trans = 50
            gpa_score = GPA_Trans * 0.2669

            IELTS_TOEFL_good = False

            # 计算语言成绩：雅思/托福
            yt_Listening = 1
            yt_Speaking = 1
            yt_Reading = 1
            yt_Writing = 1
            yt_flag = 0
            if IELTS_TOEFL > 10:  # 说明是托福成绩
                if IELTS_TOEFL > 110:
                    IELTS_TOEFL_level = 1
                    IELTS_TOEFL_good = True
                    IELTS_TOEFL_Trans = 100
                elif IELTS_TOEFL > 100:
                    IELTS_TOEFL_level = 2
                    IELTS_TOEFL_Trans = 95
                elif IELTS_TOEFL > 90:
                    IELTS_TOEFL_level = 3
                    IELTS_TOEFL_Trans = 85
                elif IELTS_TOEFL > 80:
                    IELTS_TOEFL_level = 3
                    IELTS_TOEFL_Trans = 75
                else:
                    IELTS_TOEFL_level = 4
                    IELTS_TOEFL_Trans = 70
                if (IT_Listening < 20):
                    yt_Listening = 0
                    yt_flag = 1
                if (IT_Speaking < 20):
                    yt_Speaking = 0
                    yt_flag = 1
                if (IT_Reading < 20):
                    yt_Reading = 0
                    yt_flag = 1
                if (IT_Writing < 20):
                    yt_Writing = 0
                    yt_flag = 1
            else:
                if IELTS_TOEFL >= 7.0:
                    IELTS_TOEFL_level = 1
                    IELTS_TOEFL_good = True
                    IELTS_TOEFL_Trans = 100
                elif IELTS_TOEFL >= 6.5:
                    IELTS_TOEFL_level = 2
                    IELTS_TOEFL_Trans = 90
                elif IELTS_TOEFL >= 6.0:
                    IELTS_TOEFL_level = 3
                    IELTS_TOEFL_Trans = 80
                else:
                    IELTS_TOEFL_level = 4
                    IELTS_TOEFL_Trans = 70
                if (IT_Listening < 6.0):
                    yt_Listening = 0
                    yt_flag = 1
                if (IT_Speaking < 6.0):
                    yt_Speaking = 0
                    yt_flag = 1
                if (IT_Reading < 6.0):
                    yt_Reading = 0
                    yt_flag = 1
                if (IT_Writing < 6.0):
                    yt_Writing = 0
                    yt_flag = 1

            i_score = IELTS_TOEFL_Trans * 0.2669

            # 计算GRE的值
            if GRE_Total != ''and GRE_Total is not None:
                gre = int(GRE_Total)
                if gre > 333:
                    GRE_Trans = 100
                elif gre > 325:
                    GRE_Trans = 90
                elif gre > 320:
                    GRE_Trans = 85
                elif gre > 300:
                    GRE_Trans = 80
                else:
                    GRE_Trans = 70
            else:
                GRE_Total=0
                GRE_Trans = 85
            g_score = GRE_Trans * 0.1335

            # 计算paper的分值
            if In_Papers != '' and In_Papers is not None:
                inpapers = int(In_Papers)
            else:
                In_Papers = 0
                inpapers = 0
            if Na_Papers != ''and Na_Papers is not None:
                napapers = int(Na_Papers)
            else:
                Na_Papers=0
                napapers = 0

            # 计算patent的分值
            if In_Patents != ''and In_Patents is not None:
                inpatent = int(In_Patents)
            else:
                In_Patents=0
                inpatent = 0
            if Na_Patents != ''and Na_Patents is not None:
                napatents = int(Na_Patents)
            else:
                Na_Patents=0
                napatents = 0

            paper_score = inpapers * 2.5 + napapers
            patent_score = inpatent * 2.5 + napatents
            if paper_score > 5: paper_score = 5
            if patent_score > 5: patent_score = 5

            if paper_score >= 3:
                paper_good = True;
            else:
                paper_good = False;

            if patent_score >= 3:
                patent_good = True;
            else:
                patent_good = False;
            # 计算科研，竞赛，实习，社会实践，特长的分值，不空就给分
            if Research == '':
                research_score = 0
            else:
                research_score = 5

            if Social_Practice == '':
                socialpractice_score = 0
            else:
                socialpractice_score = 4

            if Placement == '':
                placement_score = 0
            else:
                placement_score = 5

            if Specilty is '' or Specilty is None:
                Specilty = 0
                specilty_score = 0
            else:
                specilty_score = 4

            # 计算总分
            sum = i_score + gpa_score + g_score + patent_score + paper_score + specilty_score + research_score + placement_score + socialpractice_score

            # 根据成绩分为三个level
            level = 0;
            if sum > 65:
                level = 1
            elif sum < 50:
                level = 3
            else:
                level = 2

            if intention_countryId == 1:  # 选择了美国
                gu_category = University.objects.filter(gu_level=gu_level, level=level, sublevel=2)[
                    0].category_level  # 获取该学生能上的学校的category_level
                if(intention_school != '0'):
                    intention_school_qu = University.objects.filter(name=intention_school);
                university_h = University.objects.filter(gu_level=gu_level, level=level, sublevel=1,
                                                         major=intention_major).order_by('rank_major')[
                               0:6]  # 大学的级别，每档大学中的级别，所推荐学校的级别
                university_eg = University.objects.filter(gu_level=gu_level, level=level, sublevel=1,
                                                          major=intention_major).order_by('rank_major')[0:2]
                university_m = University.objects.filter(gu_level=gu_level, level=level, sublevel=2,
                                                         major=intention_major).order_by('rank_major')[0:6]
                university_l = University.objects.filter(gu_level=gu_level, level=level, sublevel=3,
                                                         major=intention_major).order_by('rank_major')[0:4]

            elif intention_countryId == 2:  # 英国
                gu_category = University_En.objects.filter(gu_level=gu_level, level=level, sublevel=2)[
                    0].category_level  # 获取该学生能上的学校的category_level
                if (intention_school != '0'):
                    intention_school_qu = University_En.objects.filter(name=intention_school);
                university_eg = University_En.objects.filter(gu_level=gu_level, level=level, sublevel=1,
                                                             major=intention_major).order_by('rank_major')[0:2]
                university_h = University_En.objects.filter(gu_level=gu_level, level=level, sublevel=1,
                                                            major=intention_major).order_by('rank_major')[
                               0:6]  # 大学的级别，每档大学中的级别，所推荐学校的级别
                university_m = University_En.objects.filter(gu_level=gu_level, level=level, sublevel=2,
                                                            major=intention_major).order_by('rank_major')[0:6]
                university_l = University_En.objects.filter(gu_level=gu_level, level=level, sublevel=3,
                                                            major=intention_major).order_by('rank_major')[0:4]
            elif intention_countryId == 3:  # 加拿大
                gu_category = University_Ca.objects.filter(gu_level=gu_level, level=level, sublevel=2)[
                    0].category_level  # 获取该学生能上的学校的category_level
                if (intention_school != '0'):
                    intention_school_qu = University_Ca.objects.filter(name=intention_school);
                university_eg = University_Ca.objects.filter(gu_level=gu_level, level=level, sublevel=1,
                                                             major=intention_major).order_by('rank_major')[0:2]
                university_h = University_Ca.objects.filter(gu_level=gu_level, level=level, sublevel=1,
                                                            major=intention_major).order_by('rank_major')[
                               0:6]  # 大学的级别，每档大学中的级别，所推荐学校的级别
                university_m = University_Ca.objects.filter(gu_level=gu_level, level=level, sublevel=2,
                                                            major=intention_major).order_by('rank_major')[0:6]
                university_l = University_Ca.objects.filter(gu_level=gu_level, level=level, sublevel=3,
                                                            major=intention_major).order_by('rank_major')[0:4]
            elif intention_countryId == 4:  # 澳大利亚
                gu_category = University_Au.objects.filter(gu_level=gu_level, level=level, sublevel=2)[
                    0].category_level  # 获取该学生能上的学校的category_level
                if (intention_school != '0'):
                    intention_school_qu = University_Au.objects.filter(name=intention_school);
                university_eg = University_Au.objects.filter(gu_level=gu_level, level=level, sublevel=1,
                                                             major=intention_major).order_by('rank_major')[0:2]
                university_h = University_Au.objects.filter(gu_level=gu_level, level=level, sublevel=1,
                                                            major=intention_major).order_by('rank_major')[
                               0:6]  # 大学的级别，每档大学中的级别，所推荐学校的级别
                university_m = University_Au.objects.filter(gu_level=gu_level, level=level, sublevel=2,
                                                            major=intention_major).order_by('rank_major')[0:6]
                university_l = University_Au.objects.filter(gu_level=gu_level, level=level, sublevel=3,
                                                            major=intention_major).order_by('rank_major')[0:4]
            no_high = 0
            no_mid = 0
            no_low = 0
            if (len(university_h) == 0):
                no_high = 1
            if (len(university_m) == 0):
                no_mid = 1
            if (len(university_l) == 0):
                no_low = 1

            # 加权计算总分
            if Recommendation == 1:  # 推荐人认识导师
                recommendation = 1;
            else:  # 不认识
                recommendation = 0;

            if intention_school == '0':  # 等于0表示没选学校
                print("没选择学校")
                result_desc='未选择目标院校'
                intention_school='无'
                UserInfoObject = UserInfoFormModel(first_name=studentFName, last_name=studentLName,
                                                   cell_phone_number=cell_phone_number,
                                                   intention_country=intention_countryName,
                                                   intention_school=intention_school,
                                                   intention_major=intention_major, graduate_school=gu_name,
                                                   ranking_in_major=rank_in_major,
                                                   score_GPA=GPA, score_IELTS_TOEFL=IELTS_TOEFL,
                                                   score_IT_Listening=IT_Listening,
                                                   score_IT_Speaking=IT_Speaking, score_IT_Reading=IT_Reading,
                                                   score_IT_Writing=IT_Writing,
                                                   score_GRE=GRE_Total, score_GRE_Quan=score_GRE_Quan,
                                                   score_GRE_Verbal=score_GRE_Verbal,
                                                   score_GRE_Anal=score_GRE_Anal, in_papers=In_Papers,
                                                   na_papers=Na_Papers, in_patent=In_Patents,
                                                   na_patent=Na_Patents, research=Research, placement=Placement,
                                                   social_practice=Social_Practice,
                                                   specilty=Specilty, recommendation=Recommendation,
                                                   result_desc=result_desc
                                                   )
                UserInfoObject.save()
                return render(request, "result_2.html",
                              {"studentFName": studentFName,
                               "studentLName": studentLName,
                               "university_h": university_h, "university_m": university_m,
                               "university_l": university_l,
                               "country": intention_countryName,
                               "in_patent": inpatent, "na_patent": napatents,
                               "in_paper": inpapers, "na_paper": napapers,
                               "GPA_level": GPA_level,
                               "IELTS_TOEFL_level": IELTS_TOEFL_level,
                               "IELTS_TOEFL_good": IELTS_TOEFL_good,
                               "GPA_good": GPA_good,
                               "result": 1,
                               "no_high": no_high,
                               "no_mid": no_mid,
                               "no_low": no_low,
                               "gu_level": int(gu_level),
                               "intention_school": intention_school,
                               "intention_major": intention_major,
                               "paper_good": paper_good,
                               "patent_good": patent_good,
                               "recommendation": recommendation,
                               "yt_Listening": yt_Listening,
                               "yt_Speaking": yt_Speaking,
                               "yt_Reading": yt_Reading,
                               "yt_Writing": yt_Writing,
                               "yt_flag": yt_flag
                               #   "intention_school":
                               })  # 直接推荐学校
            else:  # 选择了学校 intention_school
                print("选择学校")
                intention_category = intention_school_qu[0].category_level
                rank_total = intention_school_qu[0].rank_total
                rank_major = intention_school_qu[0].rank_major
                difference = int(intention_category) - int(
                    gu_category)  # 想去的学校与自己所在学校的level差，大于0代表想去的学校可以上，小于0表示上不了

                if difference <= 0:  # 如果想去的学校级别等于可以上的学校
                    if difference == 0:  # 所选的正好是可以上的，通过，成绩成绩一般
                        result = 2
                        if recommendation ==1:
                            result_desc=u'有大牛推荐，通过但成绩一般'
                        else:
                            result_desc = u'通过但成绩一般'
                    elif difference == -1:
                        result = 3  # 所选的高于可上的一级，虽然没有通过，但是可以尝试冲刺
                        if recommendation ==1:
                            result_desc=u'成绩低，因为有大牛推荐才能通过'
                        else:
                            result_desc = u'未通过，建议冲刺'
                    else:
                        result = 4;  # 所选的高于可上的2级以上,直接不通过
                        if recommendation ==1:
                            result_desc=u'成绩低，因为有大牛推荐才能通过'
                        else:
                            result_desc = u'未通过'
                else:
                    result = 5;  # 所选的学校level有点低了，可以建议选择更好的学校
                    result_desc=u'优秀'

                if GPA_level >= 4:
                    if IELTS_TOEFL_level >= 4:
                        result_desc = u'GPA和语言成绩太低，未通过'
                        result = 10
                    else:
                        result_desc = u'GPA太低，未通过'
                        result = 1
                else:
                    if IELTS_TOEFL_level >= 4:
                        result_desc = u'语言成绩太低，未通过'
                        result = 0

                UserInfoObject = UserInfoFormModel(first_name=studentFName, last_name=studentLName,
                                                   cell_phone_number=cell_phone_number,
                                                   intention_country=intention_countryName,
                                                   intention_school=intention_school,
                                                   intention_major=intention_major, graduate_school=gu_name,
                                                   ranking_in_major=rank_in_major,
                                                   score_GPA=GPA, score_IELTS_TOEFL=IELTS_TOEFL,
                                                   score_IT_Listening=IT_Listening,
                                                   score_IT_Speaking=IT_Speaking, score_IT_Reading=IT_Reading,
                                                   score_IT_Writing=IT_Writing,
                                                   score_GRE=GRE_Total, score_GRE_Quan=score_GRE_Quan,
                                                   score_GRE_Verbal=score_GRE_Verbal,
                                                   score_GRE_Anal=score_GRE_Anal, in_papers=In_Papers,
                                                   na_papers=Na_Papers, in_patent=In_Patents,
                                                   na_patent=Na_Patents, research=Research, placement=Placement,
                                                   social_practice=Social_Practice,
                                                   specilty=Specilty, recommendation=Recommendation,
                                                   result_desc=result_desc
                                                   )
                UserInfoObject.save()
                return render(request, "result_11.html",
                              {"studentFName": studentFName,
                               "studentLName": studentLName,
                               "university_h": university_h, "university_m": university_m,
                               "university_l": university_l,
                               "university_eg": university_eg,
                               "country": intention_countryName,
                               "in_patent": inpatent, "na_patent": napatents,
                               "in_paper": inpapers, "na_paper": napapers,
                               "GPA_level": GPA_level,
                               "IELTS_TOEFL_level": IELTS_TOEFL_level,
                               "IELTS_TOEFL_good": IELTS_TOEFL_good,
                               "GPA_good": GPA_good,
                               "result": result,
                               "no_high": no_high,
                               "no_mid": no_mid,
                               "no_low": no_low,
                               "gu_level": int(gu_level),
                               "intention_school": intention_school,
                               "rank_total": rank_total,
                               "rank_major": rank_major,
                               "intention_major": intention_major,
                               "paper_good": paper_good,
                               "patent_good": patent_good,
                               "recommendation": recommendation,
                               "yt_Listening": yt_Listening,
                               "yt_Speaking": yt_Speaking,
                               "yt_Reading": yt_Reading,
                               "yt_Writing": yt_Writing,
                               "yt_flag": yt_flag
                               })
        else:
           # return  HttpResponse(u'测试')
            return render(request, 'indexForm.html', {"form": form})

    else:
        form=UserInfoForm()
        return render(request, 'indexForm.html', {"form":form})