# coding:utf-8
from django import forms
from django.forms import ModelForm
from .models import UserInfoFormModel,GraduateUniver

class UserInfoForm(ModelForm):
    class Meta:
        model=UserInfoFormModel
        fields=('first_name', 'last_name','cell_phone_number','intention_country','intention_major','ranking_in_major',
                'intention_school','graduate_school','score_GPA','score_IELTS_TOEFL','score_IT_Listening',
                'score_IT_Speaking','score_IT_Reading','score_IT_Writing','score_GRE','score_GRE_Verbal',
                'score_GRE_Quan','score_GRE_Anal','in_papers','na_papers','in_patent','na_patent','research',
                'placement','social_practice','specilty','recommendation')
        widgets={
            'first_name':forms.TextInput(attrs={'placeholder': '姓','size': '8', }),
            'last_name':forms.TextInput(attrs={'placeholder': '名','size': '14', }),
            'cell_phone_number':forms.TextInput(attrs={'placeholder': '手机号码', 'class': 'large', 'pattern': '[+]?[\.\s\-\(\)\*\#0-9]{3,}'}),
            'score_GPA':forms.TextInput(attrs={'placeholder': 'GPA(4分制)', 'class': 'large', 'pattern': '[0-9]+[\.]?[0-9]*$' }),

            'score_IELTS_TOEFL':forms.TextInput(attrs={'placeholder': '雅思/托福总分', 'class': 'medium'}),
            'score_IT_Listening':forms.TextInput(attrs={'placeholder': '听力', 'class': 'medium'}),
            'score_IT_Speaking':forms.TextInput(attrs={'placeholder': '口语', 'class': 'medium'}),
            'score_IT_Reading':forms.TextInput(attrs={'placeholder': '阅读', 'class': 'medium'}),
            'score_IT_Writing':forms.TextInput(attrs={'placeholder': '写作', 'class': 'medium'}),

            'score_GRE':forms.TextInput(attrs={'placeholder': 'GRE总分', 'class': 'medium' }),
            'score_GRE_Verbal':forms.TextInput(attrs={'placeholder': 'Verbal Reasoning', 'class': 'medium'}),
            'score_GRE_Quan':forms.TextInput(attrs={'placeholder': 'Quantitative Reasoning', 'class': 'medium'}),
            'score_GRE_Anal':forms.TextInput(attrs={'placeholder': 'Analytical Writing', 'class': 'medium'}),

            'in_papers':forms.TextInput(attrs={'placeholder': '国际期刊', 'class': 'large'}),
            'na_papers':forms.TextInput(attrs={'placeholder': '其他期刊', 'class': 'large'}),
            'in_patent':forms.TextInput(attrs={'placeholder': '国际专利', 'class': 'large'}),
            'na_patent':forms.TextInput(attrs={'placeholder': '国内专利', 'class': 'large'}),
            'research':forms.Textarea(attrs={'placeholder': '简单描述你的科研经历', 'class': 'small'}),
            'placement':forms.Textarea(attrs={'placeholder': '介绍你的工作/实习经历', 'class': 'small'}),
            'social_practice':forms.Textarea(attrs={'placeholder': '简述你做过的社会实践', 'class': 'small'}),
            'specilty':forms.Textarea(attrs={'placeholder': '你的特长', 'class': 'small'}),
            'recommendation':forms.RadioSelect(),
            'intention_school': forms.Select(attrs={'prompt':'学校' , 'size': '14', }),
            #'graduate_school': forms.TextInput(attrs={'placeholder': '毕业院校', 'size': '14', }),
        }