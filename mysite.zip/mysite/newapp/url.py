from django.conf.urls import url
from newapp import views

urlpatterns = [
    #url(r'index/',views.index,name='index'),
    url(r'result/',views.assessmentForm,name='result'),
    url(r'country/',views.getUniversityList,name='getUniversityList'),
]